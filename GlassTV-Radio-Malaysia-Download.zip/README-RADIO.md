# Glass TV — Malaysia Radio Directory

Radio screen loads the Malaysia country catalog from the community Radio Browser API when opened. It filters to unique station names, HTTPS stream URLs and records marked non-broken by the directory. The number of stations varies and is shown in-app. Search and Play/Stop are supported with Android remote focusable controls.

IMPORTANT: Radio Browser's directory health status does not guarantee playback on a particular Android TV. Streams using HLS or unsupported codecs may fail with Android MediaPlayer. Internet access is required. This is not a verified complete list of every broadcaster in Malaysia. Directory server availability may change. No offline station list is bundled. Radio stops when leaving the screen.

Build: cd glass-tv-home-main/launcher && ./gradlew assembleDebug (Android SDK required). APK has not been compiled or device-tested here.
